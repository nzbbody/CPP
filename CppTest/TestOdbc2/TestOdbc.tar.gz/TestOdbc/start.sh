ulimit -c unlimited
./TestOdbc>log.txt
